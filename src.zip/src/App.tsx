import GamesPage from './pages/GamesPage';

function App() {
  return (
    <div className="app">
      <GamesPage />
    </div>
  );
}

export default App;
