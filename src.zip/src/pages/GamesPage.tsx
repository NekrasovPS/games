import React from 'react';
import GameList from '../features/games/GameList';

const GamesPage = () => {
  return (
    <div className="games-page">
      <h1>Pragmatic play</h1>
      <GameList />
    </div>
  );
};

export default GamesPage;
